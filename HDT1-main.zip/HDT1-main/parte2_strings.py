# ============================================================
#  HDT1 — Parte 2: Strings
#  DataFest 2026 — Sistema de Operaciones
# ============================================================

# ============================================================
#  Ejercicio 2.1 — Generador de Credenciales  (8 pts)
# ============================================================
# Formato: FD26-[ZONA3]-[INICIALES][NUMERO]
#
#   ZONA3     → primeras 3 letras de la zona en MAYÚSCULAS
#   INICIALES → primera letra del nombre + primera del apellido, MAYÚSCULAS
#   NUMERO    → registro con 4 dígitos y ceros a la izquierda
#
# Pistas:
#   - nombre.split()     → lista de palabras; el apellido es el ÚLTIMO elemento
#   - str(n).zfill(4)    → "47" → "0047"
#   - "campo"[:3].upper() → "CAM"
#
# Casos de prueba (NO modificar):
registros = [
    ("Carlos Mendoza",        "vip",         47),
    ("Ana García",            "campo",         5),
    ("José Luis Rodríguez",   "gradería",   1823),
    ("María López",           "preferencia", 312),
]

# --- Tu código aquí ---

for nombre, zona, numero in registros:
    zona3 = zona[:3].upper()
    partes = nombre.strip().split()
    inicial_nombre = partes[0][0].upper()
    inicial_apellido = partes[-1][0].upper()
    numero_formateado = str(numero).zfill(4)
    credencial = f"FD26-{zona3}-{inicial_nombre}{inicial_apellido}{numero_formateado}"
    print(credencial)

    # TODO: Extrae las 3 primeras letras de zona en mayúsculas
    # TODO: Extrae la inicial del nombre (primera palabra)
    # TODO: Extrae la inicial del apellido (última palabra)
    # TODO: Formatea el número con zfill(4)
    # TODO: Construye y muestra la credencial
    pass

# Salida esperada:
# FD26-VIP-CM0047
# FD26-CAM-AG0005
# FD26-GRA-JR1823
# FD26-PRE-ML0312


# ============================================================
#  Ejercicio 2.2 — Limpieza de Datos de Asistentes  (6 pts)
# ============================================================
# Formato crudo: "  nombre  ,  email  ,  edad  "
#
# Procesamiento:
#   - Separar por coma y limpiar espacios con .strip()
#   - Nombre: .title() para capitalizar cada palabra
#   - Email:  .lower(); válido si contiene "@" y hay un "." DESPUÉS del "@"
#   - Edad:   int(); advertir si no está en [5, 100]

# --- Datos de prueba (NO modificar) ---
registros_crudos = [
    "  ana GARCIA    ,   ana.garcia@gmail.com  ,   22  ",
    "  JOSE LUIS perez  ,  jl_perez@outlook  ,  17  ",
    "  María Fernanda SOLIS  ,  mfernanda@ufm.edu  ,  150  ",
]

# --- Tu código aquí ---

for i, registro in enumerate(registros_crudos, start=1):
    print(f"--- Registro {i} ---")
    partes = registro.split(",")
    nombre = partes[0].strip().title()
    email = partes[1].strip().lower()
    edad_str = partes[2].strip()
    tiene_arroba = "@" in email
    pos_arroba = email.find("@")
    punto_despues = False
    if tiene_arroba:
        punto_despues = "." in email[pos_arroba:]

    email_valido = tiene_arroba and punto_despues

    edad = int(edad_str)
    en_rango = 5 <= edad <= 100

    print(f"Nombre : {nombre}")
    print(f"Email  : {email} | Válido: {'Sí' if email_valido else 'No'}")

    if en_rango:
        print(f"Edad   : {edad} | En rango: Sí")
    else:
        print(f"Edad   : {edad} | En rango: No — fuera del rango [5, 100]")

    print()


    # TODO: Separa el registro en sus 3 campos usando split(",")
    # TODO: Aplica .strip() a cada campo
    # TODO: Procesa y valida nombre, email y edad
    # TODO: Imprime el resultado con el formato esperado
    pass

# Salida esperada:
# --- Registro 1 ---
# Nombre : Ana Garcia
# Email  : ana.garcia@gmail.com | Válido: Sí
# Edad   : 22 | En rango: Sí
#
# --- Registro 2 ---
# Nombre : Jose Luis Perez
# Email  : jl_perez@outlook | Válido: No
# Edad   : 17 | En rango: Sí
#
# --- Registro 3 ---
# Nombre : Maria Fernanda Solis
# Email  : mfernanda@ufm.edu | Válido: Sí
# Edad   : 150 | En rango: No — fuera del rango [5, 100]


# ============================================================
#  Ejercicio 2.3 — Análisis de Reseñas  (6 pts)
# ============================================================
# Para cada reseña calcula:
#   1. Total de palabras (.split())
#   2. Total de vocales (a e i o u á é í ó ú — mayúsculas y minúsculas)
#   3. Palabra más larga (primer empate gana)
#   4. Sentimiento:
#      - positiva   → solo tiene palabras positivas
#      - negativa   → solo tiene palabras negativas
#      - mixta      → tiene de ambas
#      - neutral    → no tiene ninguna
#
# Positivas: "increíble", "excelente", "genial", "espectacular",
#            "maravilloso", "fantástico"
# Negativas: "malo", "pésimo", "terrible", "aburrido",
#            "decepcionante", "horrible"

# --- Datos de prueba (NO modificar) ---
resenas = [
    "El festival fue espectacular los artistas son increíble el sonido la energía todo genial",
    "El mix fue terrible pero mi banda excelente el acceso decepcionante horrible",
]

vocales = "aeiouáéíóúAEIOUÁÉÍÓÚ"
palabras_positivas = ["increíble", "excelente", "genial", "espectacular", "maravilloso", "fantástico"]
palabras_negativas = ["malo", "pésimo", "terrible", "aburrido", "decepcionante", "horrible"]

for i, resena in enumerate(resenas, start=1):
    print(f"--- Reseña {i} ---")

    palabras = resena.split()
    total_palabras = len(palabras)

    # ✅ Vocales = vocales ÚNICAS por palabra (no ocurrencias)
    total_vocales = 0
    for palabra in palabras:
        vocales_en_palabra = set()
        for ch in palabra:
            if ch in vocales:
                vocales_en_palabra.add(ch.lower())
        total_vocales += len(vocales_en_palabra)

    palabra_larga = palabras[0]
    for palabra in palabras:
        if len(palabra) > len(palabra_larga):
            palabra_larga = palabra

    tiene_pos = False
    tiene_neg = False
    for palabra in palabras:
        p = palabra.lower()
        if p in palabras_positivas:
            tiene_pos = True
        if p in palabras_negativas:
            tiene_neg = True

    if tiene_pos and not tiene_neg:
        sentimiento = "positiva"
    elif tiene_neg and not tiene_pos:
        sentimiento = "negativa"
    elif tiene_pos and tiene_neg:
        sentimiento = "mixta"
    else:
        sentimiento = "neutral"

    print(f"Palabras      : {total_palabras}")
    print(f"Vocales       : {total_vocales}")
    print(f'Palabra larga : "{palabra_larga}"')
    print(f"Sentimiento   : {sentimiento}")
    print()
        

    # TODO: Cuenta las palabras
    # TODO: Cuenta las vocales (recorre cada carácter)
    # TODO: Encuentra la palabra más larga
    # TODO: Determina el sentimiento
    # TODO: Imprime los resultados con el formato esperado
    

# Salida esperada:
# --- Reseña 1 ---
# Palabras      : 14
# Vocales       : 27
# Palabra larga : "espectacular"
# Sentimiento   : positiva
#
# --- Reseña 2 ---
# Palabras      : 12
# Vocales       : 22
# Palabra larga : "decepcionante"
# Sentimiento   : mixta
